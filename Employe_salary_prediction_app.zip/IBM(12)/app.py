import streamlit as st
import joblib
import numpy as np
st.title("Employe Salary Prediction App")

st.divider()

st.write("With this app,you can get estimations for the salaries of the company employees")

Years = st.number_input("Enter Years", value=1, step=1, min_value=0)
Job_Rate = st.number_input("Enter Job Rate", value=3.5, step=0.5, min_value=0.0)


x=[Years,Job_Rate]

model=joblib.load("linearmodel.pkl")

st.divider()

predict=st.button("Press the Button for salary Prediction")

st.divider()

if predict:
    st.balloons()
    
    x1=np.array([x])
    
    predict=model.predict(x1)
    
    st.write(f"Employe Salary Prediction is {predict}")
    
    
else:
    "Please press the button for app to make the prediction"